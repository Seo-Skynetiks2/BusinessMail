<?php include_once "common/header.php"?>
<style type="text/css">
    .link-contact {
    color: #015790!important;
    font-weight: 600!important;
}
</style>

<section>
	<img src="images/support.jpg" style="width:100%;height: auto;">
</section>

<section class="contact-form">
	<div class="sec-title centered">
		<h2>Ask For <span>Support</span></h2>
	</div>

	<div class="container">
		<div class="row">
      <div class="col-md-9">
       <form  action="product.php" method="POST">
       	<div class="form">
            <!-- BEGIN FORM -->

            <div class="form-group row">
                	<div class="col-md-3">
                     <label>Domain Name:</label>
                     </div>
                     <div class="col-md-9">
                    <input type="text" class="form-control" name="website"  placeholder="Domain name is an internet identity of your organization i.e www.tatamotors.com" required="">
                </div>
            </div>

              <div class="form-group row">
                	<div class="col-md-3">
                    <label>Email :</label>
                     </div>
                     <div class="col-md-9">
                    <input type="email" class="form-control" name="email"  placeholder="Please fill in your direct email you always access" required="">
                </div>
            </div>

              <div class="form-group row">
                	<div class="col-md-3">
                    <label>Phone No:</label>
                     </div>
                     <div class="col-md-9">
                    <input type="tel" class="form-control" name="phone"  placeholder="Thanks for sharing your direct number." pattern="[1-9]{1}[0-9]{9}" required="">
                </div>
            </div>

           
            
                	<div class="form-group row">
                	<div class="col-md-3">
                    <label> Name:</label>
                     </div>
                     <div class="col-md-9">
                    <input type="text" class="form-control" name="name"  placeholder="How would you want us to call you?" required="">
                    </div>
                   </div>
              <div class="form-group row">
                  <div class="col-md-3">
                     <label>Message:</label>
                     </div>
                     <div class="col-md-9">
                    <textarea class="form-control" name="message" placeholder="Message" required=""></textarea>
                </div>
            </div>
             <div class="form-group row">
                     <div class="col-md-10">
                     <div class="g-recaptcha brochure__form__captcha recap" data-sitekey="6LdT_JgcAAAAAHXnZ9-hnbyoMgiWLuvOS0-zv9hS"></div>
                </div>
            </div>

                   <div class="form-group row">
                	<div class="col-md-3">
                     </div>
                     <div class="col-md-9">
                     	<button class="btn btn-primary"  style="width:100%"> Submit</button>
                    </div>
                   </div>
              
            </div>
       </form>
       </div>
        <div class="col-md-3">
        <div class="text-center logo-image-slider">
        <img src="images/shrishti.png" style="    width: 100%;
    margin-bottom: 10px;
    background: #d2ecfa;
    padding: 22px;">
    <h5 style="color: red;font-weight: 700;"><img src="images/Gsuite-logo.png" alt=""></h5>  
        <h5><marquee>Authorize Reseller partner</marquee></h5>
        <div class="outer-container text-center">

                        <div class="carousel-outer">
                            <!--Sponsors Slider-->
                            <ul class="sponsor-carousel owl-carousel owl-theme">
                                <li><div class="text-center"><a href="google-workspace-gsuite-pricing-plan-reseller-partner-india.php"><img src="images/googleworkspace.png" alt="Google Workspace, formerly known as G Suite"></a></div></li>
                                <li><div class="text-center"><a href="zoho-mail-for-business-by-shrishti-softech.php"><img src="images/zoho.png" alt="Zoho Mail is a secure and reliable business email solution"></a></div></li>
                                <li><div class="text-center"><a href="reseller-club-mail-service-shrishti-softech.php"><img src="images/resellerclub.jpg" alt="ResellerClub's Business Email Services"></a></div></li>
                                <li><div class="text-center"><a href="zimbra-mail-for-business-by-shrishti-softech.php"><img src="images/zimbramail.png" alt="Zimbra Collaboration Suite (ZCS) is an enterprise-grade mailing solution"></a></div></li>
                                <li><div class="text-center"><a href="microsoft-365-business-exchange-shrishti-softech.php"><img src="images/ms.png" alt="Microsoft 365 is our cloud-powered productivity platform"></a></div></li>
                                <li><div class="text-center"><a href="hosted-exchange-storage-business-by-shrishti-softech.php"><img src="images/hosted.png" alt="Hosted Exchange is a version of Microsoft Exchange Server "></a></div></li>
                                <li><div class="text-center"><a href="rediff-mail-pro-service-shrishti-softech.php"><img src="images/rd1.png" alt="Rediffmail Pro is a comprehensive business email solution"></a></div></li>
                                <li><div class="text-center"><a href="custom-mail-domain-google-workspace.php"><img src="images/custommail.png" alt="Custom email domain is the name of your brand "></a></div></li>
                            </ul>
                        </div>
               <div class="phone"><a href="tel:+91-9212378780"> <i class="fa fa-phone"></i><span> +91-9212378780</span></a></div>
                    </div>          
                </div>
      </div>
	</div>
</section>



<?php include_once "common/footer.php"?>
