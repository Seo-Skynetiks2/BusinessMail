<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<title>Google Workspace Reseller | Email Cloud Solution Services | G-Suite Pricing and Plan | Authorised Reseller in India | Shrishti Softech - Businessmail</title>
	<meta name="description" content="Best Reseller for Google Workspace in India,Business Mail Solutuion, Google Workspace(G suite) Reseller & Partner in India, Google Workspce(G suite) Pricing in India, Buy Google Workspace Plans Affordable Prices, Introducing google workspace, Flexible solutions for every business, Email Solution, Email managing, G-suite Email Solution, G-suite Plan, Google workspace plans, Google For workspace in India, GoogleWorkspace plan in noida">
	<meta name="keywords" content="Top Google Workspace Reseller in India, Best Reseller for Google Workspace in India, G-sutite in India, best business mail services in india, business mail in noida, business mail solution in delhi ncr, Google Workspace Free Trial business mail, google workspace plans, email migration services, zoho mail services, rc mail, zimbra mailing solutions, microsoft o365, hosted exchange, rediff mail solution, custom mail solution,payment issue with credit crad, facing payment issue with credit crad, google workspace unable to pay with credit crad, Sign Up for Google for Workspace Free Trial, Get A Free Trial for google workspace, sign up for a free google workspace trial, Business Email Setup, Google Business Mail Cost, Google workspace Mail Price, Email Solutions for small Business, Corporate Email Solutions, Google Support, Google G Suite Email Not Working, Get Google Workspace Free for Your Business, Organization, start with google workspace ">
	<meta name="author" content="Shrishti Softech Business Mail Solution">
	<meta name="google-site-verification" content="VJUz3lsM8Q4h82JQyGW-0KiC5pfLa_6V_hRvSxd7yRI" />
	<meta name="robots" content="index,follow">
	<link rel="canonical" href="https://businessmail.co.in/index.php">
	<!-- Stylesheets -->
	<link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
	<link rel="shortcut icon" href="images/logo.png" type="image/png" sizes="252x252">
	<link href="../css2.css?family=Cabin:wght@400;500;600;700&family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">
	<!-- Global site tag (gtag.js) - Google Analytics -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=UA-110332259-1"></script>
	<script>
		window.dataLayer = window.dataLayer || [];

		function gtag() {
			dataLayer.push(arguments);
		}
		gtag('js', new Date());

		gtag('config', 'UA-110332259-1');
	</script>







	<!-- <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon"> -->
	<!-- <link rel="icon" href="images/favicon.png" type="image/x-icon"> -->


	<!-- Responsive -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">


	<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
	<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body class="hidden-bar-wrapper">

	<div class="page-wrapper">

		<!-- Preloader -->
		<!-- <div class="preloader"></div> -->

		<!-- TOP HEADER -->
		<section class="top-header">
			<div class="auto-container">

				<ul id="menu-top-menu-link" class="menu menu-top">

					<li class="menu-item text-center">
						<a href="https://shrishtisoftech.com/" data-ps2id-api="true">www.shrishtisoftech.com</a>
					</li>

					<li class="menu-item text-center">
						<a href="https://getmybusinessonline.in/" data-ps2id-api="true">www.getmybusinessonline.in</a>
					</li>

					<li class="menu-item text-center">
						<a href="http://businessoncloud.in/" data-ps2id-api="true">www.businessoncloud.in</a>
					</li>

					<li class="menu-item text-center">
						<a href="http://www.hosttheweb.in/" data-ps2id-api="true">www.hosttheweb.in</a>
					</li>


					<li class="menu-item text-center">
						<a href="https://webservicesindia.info/" data-ps2id-api="true">www.webservicesindia.info</a>
					</li>
				</ul>
			</div>
		</section>

		<!-- Main Header-->
		<header class="main-header header-style-one">

			<!-- Header Top -->
			<div class="header-top">
				<div class="auto-container">
					<div class="clearfix">
						<!-- Top Left -->
						<div class="top-left">
							<!-- Info List -->
							<ul class="info-list">
								<li><a href="tel:+919212378780"><span class="icon flaticon-phone-call"></span> +91-9212378780</a></li>
								<li><a href="mailto:enquiry@businessmail.co.in"><span class="icon flaticon-email"></span> enquiry@businessmail.co.in</a></li>
							</ul>
						</div>

					</div>
				</div>
			</div>

			<!--Header-Upper-->
			<div class="header-upper">
				<div class="auto-container clearfix">

					<div class="pull-left logo-box">
						<div class="logo"><a href="index.php"><img src="images/logo.jpg" alt="Businessmail Logo" title="Businessmail Best Email Solution Provider in Noida" style="width: 80%;"></a></div>
					</div>

					<div class="nav-outer clearfix">
						<!--Mobile Navigation Toggler-->
						<div class="mobile-nav-toggler"><span class="icon flaticon-menu"></span></div>
						<!-- Main Menu -->
						<nav class="main-menu navbar-expand-md">
							<div class="navbar-header">
								<!-- Toggle Button -->
								<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
								</button>
							</div>

							<div class="navbar-collapse collapse clearfix" id="navbarSupportedContent">
								<ul class="navigation clearfix">
									<li class=""><a class="link-home" href="index.php">Home</a>
									</li>
									<li><a class="link-about" href="about-shrishti-softech-for-google-workspace-gsuite.php">About</a>
									</li>
									<li class="dropdown "><a class="link-solution" href="#">Solutions</a>
										<ul>
											<li><a href="google-workspace-gsuite-pricing-plan-reseller-partner-india.php">Google Workspace </a></li>
											<li><a href="zoho-mail-for-business-by-shrishti-softech.php">Zoho Mail</a></li>
											<li><a href="reseller-club-mail-service-shrishti-softech.php">RC Mail</a></li>
											<li><a href="zimbra-mail-for-business-by-shrishti-softech.php">Zimbra Mail</a></li>
											<li><a href="microsoft-365-business-exchange-shrishti-softech.php">Microsoft O365</a></li>
											<li><a href="rediff-mail-pro-service-shrishti-softech.php">Rediffmail Pro</a></li>
											<li><a href="hosted-exchange-storage-business-by-shrishti-softech.php">Hosted Exchange</a></li>
											<li><a href="custom-mail-domain-google-workspace.php">Custom Mail</a></li>
										</ul>
									</li>
									<li class="dropdown "><a class="link-service" href="#">Services</a>
										<ul>
											<li><a href="tech-support-by-shrishti-softech.php">Tech Support </a></li>
											<li><a href="email-migration-google-workspace-gsuite-shrishti-softech.php">Mail Migration</a></li>
										</ul>
									</li>
									<li class="dropdown "><a class="link-contact" href="#">Contact Us</a>
										<ul>
											<li><a href="sign-up-form-reseller-product-support.php">Product Sign Up </a></li>
											<li><a href="get-free-trial-google-workspace-gsuite-shrishti-softech.php">For Free Trial
												</a></li>
											<li><a href="get-call-back-google-workspace.php">Get a Call Back
												</a></li>
											<li><a href="247-support-shrishti-softech-service-google-workspace.php">Ask for Support
												</a></li>
											<li><a href="google-google-workspace-legacy-account-error-update business.php">Google legacy Account Information
												</a></li>
											<li><a href="faq-for-google-workspace-gsuite-shrishti-softech.php">FAQ
												</a></li>
										</ul>
									</li>
									<li><a href="https://shrishtisoftech.com/become-partner/" class="last">Become Partner</a>
									</li>

								</ul>
							</div>
						</nav>

						<!-- Main Menu End-->
						<div class="outer-box clearfix">

							<!-- Cart Box -->


							<!-- Search Btn -->
							<div class=""><span class="icon fa flaticon-phone-call"></span></div>

						</div>
					</div>

				</div>
			</div>
			<!--End Header Upper-->

			<!-- Sticky Header  -->
			<div class="sticky-header">
				<div class="auto-container clearfix">
					<!--Logo-->
					<div class="logo pull-left">
						<a href="index.php" title=""><img src="images/logo.jpg" style="width: 80%;" alt="shrishti softech business mail solutions services,plans,cost" title=""></a>
					</div>
					<!--Right Col-->
					<div class="nav-outer clearfix" style="display: none;">
						<div class="mobile-nav-toggler"><span class="icon flaticon-menu"></span></div>
					</div>
					<div class="pull-right">
						<!-- Main Menu -->
						<nav class="main-menu">
							<!--Keep This Empty / Menu will come through Javascript-->
						</nav><!-- Main Menu End-->

						<!-- Main Menu End-->
						<div class="outer-box clearfix">

							<!-- Cart Box -->
							<div class="cart-box">
								<div class="dropdown">
									<a href="tel:+91-9212378780"><button class="cart-box-btn" type="button"><span class="fa flaticon-phone-call"></span></button></a>

								</div>
							</div>

						</div>

					</div>
				</div>
			</div><!-- End Sticky Menu -->

			<!-- Mobile Menu  -->
			<div class="mobile-menu">
				<!-- <div class="menu-backdrop"></div> -->
				<div class="close-btn"><span class="icon flaticon-multiply"></span></div>

				<nav class="menu-box">
					<div class="nav-logo"><a href="index.php"><img src="images/logo.jpg" alt="" title=""></a></div>
					<div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
				</nav>
			</div><!-- End Mobile Menu -->

		</header>
		<!-- End Main Header -->
		<style type="text/css">
			.main-header {
				position: inherit;
			}

			.link-solution {
				color: #015790 !important;
				font-weight: 600 !important;
			}
		</style>


		<section class="city" style="background:linear-gradient(rgb(33 109 161 / 81%), rgb(1 87 146 / 33%)),url(images/google_workspace_banner.png);background-repeat: no-repeat;
    background-size: 100% 100%;">
			<div class="container">
				<div class="text-center city_banner">
					<h4>Google Workspace</h4>
					<div class="btns-box">
						<a href="#" class="theme-btn btn-style-one"><span class="txt" data-toggle="modal" data-target="#callback">Get a Call Back</span></a>
					</div>
				</div>

			</div>
		</section>

		<section class="google_workspace_content">
			<div class="container">
				<div class="sec-title centered">
					<h1>Google Workspace <span style="color: #0fb31a;">in India</span> </h1>
				</div>
				<div class="row">
					<div class="col-md-6">

						<div class="text-content">
							<p>
								Google Workspace, formerly known as G Suite, is a comprehensive collection of cloud computing, productivity, and collaboration tools developed and marketed by Google. Initially launched in 2006 as "Google Apps for Your Domain," it was later rebranded as "G Suite" in 2016.

								</br>
								</br>


								Google Workspace is designed to provide an all-in-one suite of web applications that facilitate improved team collaboration and enhanced business productivity. Some of the key features and functionalities offered by Google Workspace include Gmail, Docs, App Maker, Google Meet, Cloud Search, and many others. With these tools, teams can work together seamlessly and efficiently, making it easier to generate and share ideas while streamlining various business processes.

							</p>

						</div>
					</div>
					<div class="col-md-6">
						<img src="images/gw1.jpeg">
					</div>
				</div>
			</div>

		</section>

		<section class="pricing_table">
			<div class="container">
				<div class="sec-title centered">
					<h2>Google Workspace <span>Pricing and Plans</span> </h2>
				</div>
				<div class="row">
					<div class="col-md-3 col-sm-6">
						<div class="pricingTable10">
							<div class="pricingTable-header">
								<h3 class="heading">Business Starter</h3>
								<span class="price-value">
									<span class="currency">₹</span> 2760
									<span class="month">/ Yr</span>
								</span>
								<p style="color: white;">per user / one-year commitment</p>

								<span class="price-value">
									<span class="currency">₹</span> 3312
									<span class="month">/ Yr</span>
								</span>

								<p style="color: white;">Flex no commitment</p>


							</div>
							<div class="pricing-content">
								<ul>
									<li>Custom and secure business email</li>
									<li>100 participant video meetings</li>
									<li>30GB Monthly Bandwidth</li>
									<li>Security and management controls</li>
									<li>Standard Support</li>
								</ul>
								<span data-toggle="modal" data-target="#signup_pricing"><a href="#" class="read">sign up</a></span>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
						<div class="pricingTable10">
							<div class="pricingTable-header">
								<h3 class="heading">Business Standard</h3>
								<span class="price-value">
									<span class="currency">₹</span> 11040
									<span class="month">/Yr</span>
								</span>
								<p style="color: white;">per user / one-year commitment</p>

								<span class="price-value">
									<span class="currency">₹</span> 13248
									<span class="month">/ Yr</span>
								</span>

								<p style="color: white;">Flex no commitment</p>

							</div>
							<div class="pricing-content">
								<ul>
									<li>Custom and secure business email</li>
									<li>150 participant video meetings + recording</li>
									<li>2 TB cloud storage per user</li>
									<li>Security and management controls</li>
									<li>Standard Support (paid upgrade to Enhanced Support)</li>
								</ul>
								<span data-toggle="modal" data-target="#signup_pricing"><a href="#" class="read">sign up</a></span>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
						<div class="pricingTable10">
							<div class="pricingTable-header">
								<h3 class="heading">Business Plus</h3>
								<span class="price-value">
									<span class="currency">₹</span> 16560
									<span class="month"> /Yr</span>
								</span>
								<p style="color: white;">per user / one-year commitment</p>

								<span class="price-value">
									<span class="currency">₹</span> 19872
									<span class="month">/ Yr</span>
								</span>

								<p style="color: white;">Flex no commitment</p>

							</div>
							<div class="pricing-content">
								<ul>
									<li>Custom and secure business email + eDiscovery, retention</li>
									<li>250 participant video meetings + recording, attendance tracking</li>
									<li>5 TB cloud storage per user</li>
									<li>Enhanced security and management controls, including Vault and advanced endpoint management</li>
									<li>Standard Support (paid upgrade to Enhanced Support)</li>
								</ul>
								<span data-toggle="modal" data-target="#signup_pricing"><a href="#" class="read">sign up</a></span>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
						<div class="pricingTable10">
							<div class="pricingTable-header">
								<h3 class="heading">Enterprise</h3>
								<span class="price-value">
									<span class="currency"></span>Contact Us<span class="month"></span>
								</span>
								<p style="color: white;">Contact sales for pricing</p>
							</div>
							<div class="pricing-content">
								<ul>
									<li>Custom and secure business email + eDiscovery, retention, S/MIME encryption</li>
									<li>250 participant video meetings + recording, attendance tracking, noise cancellation, in-domain live streaming</li>
									<li>As much storage as you need</li>
									<li>Advanced security, management, and compliance controls, including Vault, DLP, data regions, and enterprise endpoint management</li>
									<li>Enhanced Support (paid upgrade to Premium Support)</li>
								</ul>
								<span data-toggle="modal" data-target="#signup_pricing"><a href="#" class="read">sign up</a></span>
							</div>
						</div>
					</div>
				</div>

				<p style="font-size: 16px;
    padding: 10px 0px;">
					<sapn style="color:red;font-size: 18px;">*</sapn> Offer available to new Google Workspace customers only. This introductory price is only available for the first 20 users added, for 12 months. Standard pricing will apply to all users after 12 months. Customers may cancel at any time.
				</p>
			</div>
		</section>


		<section class="benifits">

			<div class="container">
				<div class="sec-title centered">
					<h2>Google Workspace <span>Benefits</span> </h2>
				</div>
				<div class="row">
					<div class="col-md-6">
						<div class="benifit_list">
							<div class="row">
								<div class="col-md-2 col-3">
									<img src="images/b1.jpg" style="width: 100%">
								</div>
								<div class="col-md-10 col-9">
									<div class="content-benifit">
										<h4>Logging in made easy</h4>

										<p>Having to remember multiple login details can be tricky, but with single sign-on, you can allow your employees to log in using their Google Workspace (formerly G Suite) credentials (email and password). This eliminates the need for employees to remember an additional password; they simply select the option to log in using this method. With studies reporting that forgetting passwords is considered 'more annoying than losing keys,' implementing single sign-on for new software becomes a blessing for everyone.</p>


									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="col-md-6">
						<div class="benifit_list">
							<div class="row">
								<div class="col-md-2 col-3">
									<img src="images/googleworkspace.png" style="width: 100%">
								</div>
								<div class="col-md-10 col-9">
									<div class="content-benifit">
										<h4>Never miss a meeting</h4>
										<p>The Appogee HR integration with Google Workspace synchronizes your leave and sickness requests with your Google Calendar instantly. Once an employee submits a leave request, it will be automatically synced to their calendar and appear as a "Pending Request." Upon approval, it will be updated to display as an "Approved Request." Furthermore, the Google Workspace integration extends to Google Team Calendars, enabling you to sync leave information across the entire team, facilitating better coordination for daily tasks.</p>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="col-md-6">
						<div class="benifit_list">
							<div class="row">
								<div class="col-md-2  col-3">
									<img src="images/gsuite.png" style="width: 100%">
								</div>
								<div class="col-md-10 col-9">
									<div class="content-benifit">
										<h4>Access from any Google Workspace application</h4>
										<p>You can open Appogee HR from any one of your Google Workspace applications. Just use the easily accessible menu in the top right corner of any of the apps. There is no need to remember URLs or save another bookmarked web page. With this handy feature, Appogee HR will appear right alongside your other most-used apps, such as Calendar, Drive, Docs, and Sheets.</p>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="col-md-6">
						<div class="benifit_list">
							<div class="row">
								<div class="col-md-2  col-3">
									<img src="images/shristibestofluck.png" style="width: 100%">
								</div>
								<div class="col-md-10 col-9">
									<div class="content-benifit">
										<h4>Set your out of office </h4>
										<p>One of the most loved integration points for Google Workspace is the ability to set Out of Office messages when making a Leave request. Remembering to set an Out of Office message on the last day before a period of absence is often something employees forget to do. However, with the convenience of setting it directly from within Appogee HR, you no longer need to worry about this and can focus on other more important tasks, such as handovers and preparing to enjoy your break!</p>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="col-md-6">
						<div class="benifit_list">
							<div class="row">
								<div class="col-md-2  col-3">
									<img src="images/cloud.png" style="width: 100%">
								</div>
								<div class="col-md-10 col-9">
									<div class="content-benifit">
										<h4> Fast user upload</h4>
										<p>When adding new employees to Appogee HR, you can select to import them via Google Workspace. This automated process saves you significant time and effort, as it eliminates the need for a tedious and lengthy manual entry. Once integrated, Appogee HR identifies which users within your Google Workspace domain have not been set up yet. By choosing to upload users from Google Workspace, you can promptly identify and assign the new employees to a team, ensuring they are quickly activated and ready to go.</p>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="col-md-6">
						<div class="benifit_list">
							<div class="row">
								<div class="col-md-2  col-3">
									<img src="images/clock.png" style="width: 100%">
								</div>
								<div class="col-md-10 col-9">
									<div class="content-benifit">
										<h4>Save time uploading records</h4>
										<p>Employee records, absence attachments, and company policies are essential factors of any HR management system. Since you are already using Google Workspace, it is likely that these documents and records are stored within your Google Drive. As an additional productivity bonus, you can use the Drive picker to easily link to the documents you have stored in Google Drive with just a couple of clicks. This way, you won't need to search for documents or create multiple versions, making the process more efficient and streamlined.</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>


		<section class="city" style="background:url(images/google_workspace.jpg);background-repeat: no-repeat;
    background-size: 100% 100%;">
			<div class="container">
				<div class="text-right city_banner">
					<a href="#" class="theme-btn btn-style-three" data-toggle="modal" data-target="#myModal"><span class="txt">Get A Quote</span></a>
				</div>

			</div>
		</section>
		<?php include_once "common/service_network.php" ?>
		<?php include_once "common/footer.php" ?>